import React, { useState, useEffect } from 'react'
import { Link, useNavigate } from "react-router-dom";
const Navbar = () => {
    const userid = sessionStorage.getItem('userid')
    const [user, Setuser] = useState('')
    const [deleteid, Setdeleteid] = useState('')
    const tokenstring = sessionStorage.getItem('token')
    const navigate = useNavigate();

    const logout = () => {
        sessionStorage.clear();
        navigate('/login');
    }

    const deleteAccount = (_id) => {
        fetch(`https://api.pinkspot.cc/api/v1/users/updateUserStatus/${_id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ status: "DELETE" })

        }).then((result) => {
            result.json().then((res) => {
                sessionStorage.clear();
                navigate('/');
            })
        })
    }

    const getuser = () => {
        fetch(`https://api.pinkspot.cc/api/v1/users/${userid}`)
            .then(response => {
                return response.json()
            }).then(data => {
                Setuser(data)
            })
    }

    useEffect(() => {
        getuser();
    }, [])// eslint-disable-line react-hooks/exhaustive-deps

    return (
        <>
            <nav className="navbar navbar-expand-lg bg-purple">
                <div className="container-fluid px-lg-5 ">
                    <Link to="/" ><img className="logo" src={require("../img/pink-logo-new.png")} alt="sgdg" /></Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    {tokenstring ? <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li>
                                {user?.image !== "" ? <img className='profile-img' src={user?.image} alt="sgdg" /> : <img className='profile-img' src={require("../img/user.jpg")} alt="sgdg" />}
                            </li>
                            <li>
                                <div className="dropdown">
                                    <button className=" dropdown-toggle nav-drops" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"></button>
                                    <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                        <li><Link className="dropdown-item" to="/mypost">My Ads</Link></li>
                                        <li><Link className="dropdown-item" to="/mypost">My Order</Link></li>
                                        <li><Link className="dropdown-item" to="/user-profile">My Profile</Link></li>
                                        <li><Link className="dropdown-item" to="/user-profile">Account Settings</Link></li>
                                        <li><Link className="dropdown-item" to="/Contact-us">Help</Link></li>
                                        <li><button className="dropdown-item" data-bs-toggle="modal" data-bs-target="#myModals" onClick={() => { Setdeleteid(userid) }}>Delete Account</button></li>
                                        <li><Link className="dropdown-item" to="/" onClick={logout}>Logout</Link></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                        <Link to="/post" className="nav-btn ">Post Ad</Link>
                    </div> : <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li className="nav-item"><Link className="nav-link blue-nav" to="/sign-up" >Sign Up</Link></li>
                            <li className="nav-item"><Link className="nav-link blue-nav" to="/login" >Login</Link></li>
                        </ul>
                    </div>}
                </div>
            </nav>
            <div className="modal fade" id="myModals">
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div className="modal-body">
                            Do You Want To Delete Permanently
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="nav-btn" data-bs-dismiss="modal" onClick={() => deleteAccount(deleteid)}>Yes</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Navbar