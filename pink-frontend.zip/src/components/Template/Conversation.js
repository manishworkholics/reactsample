import React, { useEffect, useState } from 'react'

const Conversation = ({ data, currentUser, online }) => {
    const [userData, setUserData] = useState(null)

    useEffect(() => {

        const userId = data.members.find((id) => id !== currentUser)
        const getUserData = async () => {
            fetch(`https://api.pinkspot.cc/api/v1/users/${userId}`)
                .then(response => {
                    return response.json()
                }).then(data => {
                    setUserData(data)
                    // dispatch({ type: "SAVE_USER", data: data })
                })
        }
        getUserData();
    }, [])// eslint-disable-line react-hooks/exhaustive-deps

    return (
        <>
            <div className="follower conversation">
                <div>
                    {online && <div className="online-dot"></div>}
                    <img
                        src={require("../img/user.jpg")}
                        alt="Profile"
                        className="followerImage"
                        style={{ width: "50px", height: "50px" }}
                    />
                    <div className="name" style={{ fontSize: '0.8rem' }}>
                        <span>{userData?.name}</span>
                        <span style={{ color: online ? "#51e200" : "" }}>{online ? "Online" : "Offline"}</span>
                    </div>
                </div>
            </div>
            {/* <hr style={{ width: "85%", border: "0.1px solid #ececec" }} /> */}
        </>
    )
}

export default Conversation