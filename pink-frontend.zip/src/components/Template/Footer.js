import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
    const tokenstring = sessionStorage.getItem('token')
    return (
        <>
            <div className="bottom_footer">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3 d-none-mobile d-flex align-items-center">
                            <p>Copyright © 2023 Pink</p>
                        </div>
                        <div className="col-lg-5 d-flex align-items-center justify-content-center">
                            <div className="footer-list">
                                <Link className="link mx-3" to="/term-of-services">Terms of Service</Link>
                                <Link className="link mx-3" to="/privacy-policy">Privacy Policy</Link>
                                <Link className="link mx-3" to="/rules">Rules</Link>
                            </div>
                        </div>
                        <div className="col-lg-4">
                            <ul className="social_icon">
                                <li><Link to=""><img src={require("../img/insta.png")} className="youtube" alt='m-learning' /></Link></li>
                                <li><Link to=""><img src={require("../img/linkdin.png")} alt='m-learning' /></Link></li>
                                <li><Link to=""><img src={require("../img/twiter.png")} alt='m-learning' /></Link></li>
                                <li><Link to=""><img src={require("../img/facebook.png")} alt='m-learning' /></Link></li>
                                {tokenstring ? <li> <Link to='/post' className="nav-btn ">Post Ad</Link></li> : ''}
                            </ul>
                        </div>
                        <div className="col-lg-3 d-none-desktop">
                            <p>Copyright © 2023 Pink</p>
                        </div>

                    </div>
                </div>
            </div>
        </>
    );
};

export default Footer;