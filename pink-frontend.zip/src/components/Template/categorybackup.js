import React, { useState, useEffect } from 'react'
import Navbar from './../Template/Navbar'
import Footer from './../Template/Footer'
// import Login from './Login'
import Preloader from '../Template/Preloader';
import TimeAgo from 'javascript-time-ago'
import ReactTimeAgo from 'react-time-ago'
import en from 'javascript-time-ago/locale/en.json'
import { Link } from "react-router-dom";
import { useLocation } from 'react-router-dom'


const Category = () => {
    TimeAgo.setDefaultLocale(en.locale)
    TimeAgo.addLocale(en)
    // TimeAgo.addDefaultLocale(en)
    const [spinner, setSpinner] = useState(false);
    const location = useLocation();
    // const usertoken = sessionStorage.getItem('token')
    const { id ,filter} = location.state;
    const [subcategory, Setsubcategory] = useState('')
    const [post, Setpost] = useState('')

    const getsubcategory = () => {
        fetch(`https://api.pinkspot.cc/api/v1/category/getsubcategorybycatid/${id}`)
            .then(response => {
                return response.json()
            }).then(data => {
                Setsubcategory(data)
            })
    }
    const getpostbysubcategory = (id) => {
        fetch(`https://api.pinkspot.cc/api/v1/postad/getpostadby_subcategory_id/${id}`)
            .then(response => {
                return response.json()
            }).then(data => {
                Setpost(data)
            })
    }
    const getpost = () => {
        setSpinner(true);
        fetch(`https://api.pinkspot.cc/api/v1/postad/getpostadby_category_id/${id}/${filter}`)
            .then(response => {
                return response.json()
            }).then(data => {
                Setpost(data)
                setSpinner(false);
            })
    }

    useEffect(() => {
        getpost();
        getsubcategory();
        window.scrollTo({ behavior: 'smooth', top: 0 })
    }, [])// eslint-disable-line react-hooks/exhaustive-deps
    // if (!usertoken) {
    //     return <Login />
    // }
    console.log(filter)
    return (
        <>
            <Navbar />
            <div className='container mt-3' >
                <div className='row'>
                    {subcategory.data?.map((val, index) => {
                        return (
                            <div className='col-6 col-md-2' key={index}>
                                <button className='sub-cat-btn' onClick={() => getpostbysubcategory(val._id)}>
                                    {/* <span class="material-symbols-outlined">{val.iconname}</span> */}
                                    {val.name}</button>
                            </div>
                        )
                    })}
                </div>
            </div>
            <div className='container mt-2'>
                <div className='row'>
                    <div className='col-6 col-md-2' >
                        <button className='sub-cat-btn' onClick={getpost}>All post</button>
                    </div>
                </div>
            </div>

            <div className='container box-detail' style={{ minHeight: '100vh' }}>

                <div className='row'>

                    <div className='col-md-9'>
                        {spinner && (
                            <Preloader />
                        )}
                        {post.data?.map((val, index) => {
                            return (
                                <Link to='/add' state={{ data: val }} className='categeory-card' id={index} >
                                    <div className='img-box'><img src={val.image1} alt="sgdg" /></div>
                                    <div className='card-text'>
                                        <h6>{val.title}</h6>
                                        <span className='ml-2'>Posted <ReactTimeAgo date={val.createdAt} locale="en-US" /></span> |<span className='mx-2'>City: {val.city}</span>
                                        <p>{val.description}</p>
                                        {val.isVerified !== true ? <button className='btn'><img className="verified-logo" src={require("../img/verified.png")} alt="sgdg" />Verified</button> : ''}

                                    </div>
                                </Link>

                            )
                        })}

                    </div>
                    <div className='col-md-3'></div>
                </div>

            </div>
            <Footer />
        </>
    )
}

export default Category