import React from 'react'

const Preloader = () => {
    return (
        <div className='preloader-css'><img src={require("../img/ReflectingEthicalDikkops-max-1mb.gif")} alt='loader' /></div>
    )
}

export default Preloader