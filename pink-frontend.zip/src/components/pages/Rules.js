import React, { useState, useEffect } from "react";

import Header from "./../Template/Header";
import Footer from "./../Template/Footer";
import Helmet from "react-helmet";
const Rules = () => {
  const [seo, setSeo] = useState();
  const getseoetail = () => {
    fetch(`https://api.pinkspot.cc/api/v1/pages/getPageById/653281cdefe8c2f29fdcecaf`)
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        setSeo(data);
      });
  };

  useEffect(() => {

    getseoetail();

  }, []);
  return (
    <div >
      <Helmet>
        <title>{seo?.data?.seotitle}</title>
        <meta name="description" content={seo?.data?.seodescription} />
        <meta name="keywords" content={seo?.data?.seokeyword} />
        <meta name="author" content="PINK SPOT" />
        <meta property="og:title" content={seo?.data?.seotitle} />
        <meta property="og:description" content={seo?.data?.seodescription} />
        <meta property="og:image" content={seo?.data?.seoimageurl} />
        <meta property="og:url" content={`https://pinkspot.cc/rules`} />
      </Helmet>
      <Header />
      <div className='container-fluid  term-condition'>
        <div className='row'>
          <div className='col-md-12 term-background'>
            <h3 className='text-center'>OFFICIAL RULES & POSTING GUIDELINES</h3>
          </div>
        </div>
      </div>
      <div className='container mt-3'>
        <div className='row'>
          <div className='col-md-12'>

            <p className='text-responsive'>
              These Official Rules apply to every user or member who posts ads in our website. To post or respond to any ads you must behave in a peaceful, civil, prudent and respectful manner at all times. You hereby acknowledged that we do not review or monitor any post or any respond thereof board. We have provided the following guidelines to make sure our users or members will interact freely and will avoid any harmful or illegal activities.
            </p>
          </div>
        </div>
      </div>
      <div className='container mt-3'>
        <div className='row'>
          <div className='col-md-12'>
            <h3>RESTRICTED CONTENT:</h3>
            <p className='text-responsive'>
              Your ads content including but not limited to any words, pictures, audios, videos, images, etc. should not infringe the intellectual property rights or privacy rights of others and should not contain anything defamatory, fraudulent, deceptive, inaccurate, abusive, threatening, offensive, and obscene or promote any drug-related or illegal activities.
            </p>
          </div>
        </div>
      </div>
      <div className='container mt-3'>
        <div className='row'>
          <div className='col-md-12'>
            <h3>AD RULES:</h3>
            <p className='text-responsive'>
              We are offering one free ads per day. If you want to post more ads you can do so by paying a certain fees each time and to use our services or post any ads in our website you hereby agree to the following rules, including but not limited to
            </p>
            <p>•	Post you ads in the right category</p>
            <p>•	do not post anything or post as frequently which may looks spam</p>
            <p>•	If you are a free user, don’t create or use more than one account, creating or posting from multiple accounts will terminate or restrict you use of our website and its services.</p>
            <p>•	If you are a paid user, you can have multiple paid accounts.</p>
            <p>•	Do not advertisement or promote any goods or services such as weapons, illegal drugs, used or recalled food and cosmetics; ID cards, counterfeit or pirated items, and child pornography, human trafficking, or the exploitation or endangerment of minors.</p>
            <p>•	Do not Advertise or solicit directly or in any “coded” fashion any illegal service, including an offer to provide sexual services for money or other consideration</p>

          </div>
        </div>
      </div>
      <div className='container mt-3'>
        <div className='row'>
          <div className='col-md-12'>
            <h3>REPORTING:</h3>
            <p className='text-responsive'>
              You can report us at support@pinkspot.cc if you suspect or if you have a reasonable belief that any ads content posted or published on our website violate our Terms of Service, gives misleading information, or serves the purpose of harassing or endangering yourself or others or infringe any intellectual property rights or copyrights .If you have a reason to suspect that content distributed might be of suspected criminal activity, please report it immediately to the appropriate law enforcement agency. Once contacted by the proper authorities we will cooperate to the fullest extent possible. We will not act on allegations or suspicions.
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}

export default Rules