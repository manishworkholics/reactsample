import React, { useState, useEffect } from "react";

import { Link, useNavigate } from "react-router-dom";
import Helmet from "react-helmet";
const Signup = () => {
    const [seo, setSeo] = useState();
    const [user, setUser] = useState({ email: "", password: "", phone: "" });
    const [isChecked, setIsChecked] = useState(() => !!localStorage.checkbox);

    const navigate = useNavigate();
    const handleChange = (e) => {
        const name = e.target.name
        const value = e.target.value
        setUser({ ...user, [name]: value })
    }

    const submitData = async (e) => {
        e.preventDefault();
        if (!isChecked) {
            // alert('Please accept term of condition');
            return;
        }
        const { email, password, phone } = user;

        const data = fetch("https://api.pinkspot.cc/api/v1/users/register", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ email, password, phone })
        });
        const response = await data;
        const res = await response.json()

        if (response.status === 200) {

            navigate('/otp');
            localStorage.setItem('userid', res?.data._id);

            // window.alert("OTP SEND ON YOUR MAIL ID");

        }

        // if (response.status === 500 || !response) {
        //     window.alert("invalid registration");
        // }
    }

    const getseoetail = () => {
        fetch(`https://api.pinkspot.cc/api/v1/pages/getPageById/6532643cefe8c2f29fdce978`)
            .then((response) => {
                return response.json();
            })
            .then((data) => {
                setSeo(data);
            });
    };

    useEffect(() => {

        getseoetail();

    }, []);
    return (
        <>
            <Helmet>
                <title>{seo?.data?.seotitle}</title>
                <meta name="description" content={seo?.data?.seodescription} />
                <meta name="keywords" content={seo?.data?.seokeyword} />
                <meta name="author" content="PINK SPOT" />
                <meta property="og:title" content={seo?.data?.seotitle} />
                <meta property="og:description" content={seo?.data?.seodescription} />
                <meta property="og:image" content={seo?.data?.seoimageurl} />
                <meta property="og:url" content={`https://pinkspot.cc/term-of-services`} />
            </Helmet>
            <div className='container-fluid'>
                <div className='row mt-2'>
                    <div className='col-md-1'></div>
                    <div className='col-md-4'>
                        <div className='signup-boxone'>
                            <img src={require("../img/logo.png")} alt="sgdg" />
                            <h4 className='text-center'>Sign Up</h4>
                            <div className='form'>
                                <form onSubmit={submitData}>
                                    <div className="mb-2 mt-3">
                                        <label htmlFor="email" className="form-label">Email</label>
                                        <input type="email" className="form-control" id="email" value={user.email} name="email" onChange={handleChange} required />
                                    </div>
                                    <div className="mb-2">
                                        <label htmlFor="no" className="form-label">Mobile Number</label><br />
                                        <input type="number" className="form-control" id="phone" value={user.phone} name="phone" onChange={handleChange} required />
                                    </div>
                                    <div className="mb-2">
                                        <label htmlFor="pwd" className="form-label">Password</label>
                                        <input type="password" className="form-control" id="password" value={user.password} name="password" onChange={handleChange} required />
                                    </div>
                                    <div className="mb-2">
                                        <label htmlFor="pwd" className="form-label">Confirm Password</label>
                                        <input type="password" className="form-control" id="cpassword" value={user.password} name="password" onChange={handleChange} required />
                                    </div>
                                    {/* <div className='btn-box'>
                                        <button type="submit" className="btn">Client (View Ads)</button>
                                        <button type="submit" className="btn">Advertise  (Post Ad)</button>
                                    </div> */}
                                    <div className="form-check mb-2 mt-2">
                                        <label className="form-check-label">
                                            <input
                                                type="checkbox"
                                                checked={isChecked}
                                                name="agree"
                                                onChange={(e) => setIsChecked(e.target.checked)}
                                            />
                                            <Link className=" text-center" to="/term-of-services">  I agree with Terms&Conditions</Link>
                                        </label>
                                    </div>
                                    <button type="submit" className="btn submit-btn">Submit</button>
                                    <div className='text-center'>
                                        <p >Already have an account</p>
                                        <Link className="login-link text-center" to="/login">Log In</Link>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div className='col-md-2'></div>
                    <div className='col-md-4'>
                        <div className='signup-box'>

                        </div>
                        <div className='col-md-1'></div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Signup