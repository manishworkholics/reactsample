import React, { useEffect, useState } from "react";
import Header from "./../Template/Header";
import Footer from "./../Template/Footer";
import { Link } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import { FreeMode, Pagination } from "swiper";
import "swiper/css";
import "swiper/css/pagination";
import Helmet from "react-helmet";

const Home = () => {
  const [category, Setcategory] = useState("");
  const [post, Setpost] = useState("");
  const [isActive, setIsActive] = useState("");
  const [active, setActive] = useState();
  const [activeUnFav, setActiveUnFav] = useState();
  const [seo, setSeo] = useState();


  const getpost = () => {
    fetch(`https://api.pinkspot.cc/api/v1/postad/getallpostad_sort_desc`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        'X-API-Key': "your-api-key1"
      },
      body: JSON.stringify({ limit: "12" }),
    })
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        Setpost(data);
        setActive("");
        setIsActive("");
        setActiveUnFav("");
      });
  };

  const favouriteByuserid = sessionStorage.getItem("userid");
  const FavoriteClick = async (favouriteToPostid) => {
    setIsActive(favouriteToPostid);
    var favouriteByuserid = sessionStorage.getItem("userid");
    if (!favouriteByuserid) {
      alert("Please Login");
      return;
    }
    const fetchdata = fetch(
      "https://api.pinkspot.cc/api/v1/postad/favouritesubmit",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ favouriteByuserid, favouriteToPostid }),
      }
    );

    const response = await fetchdata;
    await response.json();
    if (response.status === 200) {
      getpost();
    } else {
      console.log("error");
    }
  };

  const UnFavFavoriteClick = async (favouriteToPostid) => {
    var favouriteByuserid = sessionStorage.getItem("userid");
    if (!favouriteByuserid) {
      alert("Please Login");
      return;
    }
    const fetchdata = fetch(
      "https://api.pinkspot.cc/api/v1/postad/favouritesubmit",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ favouriteByuserid, favouriteToPostid }),
      }
    );

    const response = await fetchdata;
    await response.json();
    if (response.status === 200) {
      getpost();
    } else {
      console.log("error");
    }
  };
  const [modalactive, setModalActive] = useState("block"); //model
  const setModalHide = () => {
    setModalActive("none");
    localStorage.setItem("agreemodal", "true");
  };
  useEffect(() => {
    const ls = localStorage.getItem("agreemodal");
    if (ls) {
      setModalActive("none");
    }
  }, []);
  const getcategory = () => {
    fetch(`https://api.pinkspot.cc/api/v1/category/getallcategory`, { headers: { 'X-API-Key': "your-api-key1" } })
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        Setcategory(data);
      });
  };
  const getseoetail = () => {
    fetch(`https://api.pinkspot.cc/api/v1/pages/getPageById/65325f50efe8c2f29fdce961`)
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        setSeo(data);
      });
  };

  useEffect(() => {
    getpost();
    getcategory();
    getseoetail();
    window.scrollTo({ behavior: "smooth", top: 0 });
  }, []);

  return (
    <>
      <Header />

      <Helmet>
        <title>{seo?.data?.seotitle}</title>
        <meta name="description" content={seo?.data?.seodescription} />
        <meta name="keywords" content={seo?.data?.seokeyword} />
        <meta name="author" content="PINK SPOT" />
        <meta property="og:title" content={seo?.data?.seotitle} />
        <meta property="og:description" content={seo?.data?.seodescription} />
        <meta property="og:image" content={seo?.data?.seoimageurl} />
        <meta property="og:url" content={`https://pinkspot.cc/`} />
      </Helmet>

      <div className="slider-box">
        <Swiper
          slidesPerView={5}
          spaceBetween={10}
          freeMode={true}
          pagination={{
            clickable: true,
          }}
          breakpoints={{
            "@0.00": {
              slidesPerView: 1,
              spaceBetween: 10,
            },
            "@0.75": {
              slidesPerView: 2,
              spaceBetween: 20,
            },
            "@1.00": {
              slidesPerView: 3,
              spaceBetween: 40,
            },
            "@1.50": {
              slidesPerView: 4,
              spaceBetween: 50,
            },
            "@2.00": {
              slidesPerView: 5,
              spaceBetween: 60,
            },
          }}
          modules={[FreeMode, Pagination]}
          className="mySwiper"
        >
          {post?.data?.map((val, index) => {
            return (
              <SwiperSlide style={{ minHeight: '280px' }}>
                <div className="img-box">
                  <Link key={index} to={`/profile/${val?.city.split(" ").join("-")}/${val?.slug}`} state={{ data: val }} onClick={onscroll} > {" "} <img src={val.image1} alt="sgdg" />  </Link>
                  <p className="heading ">
                    {val.name}
                    {val.favouritepostbyuser.indexOf(favouriteByuserid) ? (
                      <span>
                        <i className={`${active === val._id ? "fa-solid fa-heart like-active" : "fa-regular fa-heart dislike-active"}`} id={val._id} onClick={() => { setActive(val._id); FavoriteClick(val._id); }} ></i>
                      </span>
                    ) : (
                      <i className={`${activeUnFav === val._id ? "fa-regular fa-heart dislike-active" : "fa-solid fa-heart like-active"}${isActive === val._id ? "fa-regular fa-heart dislike-active" : "fa-solid fa-heart like-active"}`} id={val._id} onClick={() => { setActiveUnFav(val._id); UnFavFavoriteClick(val._id); }}  ></i>
                    )}
                  </p>
                  <p className="contact">{val.city}</p>
                  <p></p>
                </div>
              </SwiperSlide>
            );
          })}
        </Swiper>
      </div>


      <div className="container home-category">
        <div className="row">
          {category.data?.map((val, index) => {
            return (
              <div className="col-md-2 col-4 text-center" key={index} >
                <Link to={`/${val?.slug}`} state={{ id: val._id }} className="home-category-box" >
                  {val.active ? <img className="material-symbols-outlined" style={{ background: '#F6ACCA' }} src={val.iconname} alt="" /> : <img className="material-symbols-outlined" src={val.iconname} alt="" />}
                  <h6 className="text-center">{val.name}</h6>
                </Link>
              </div>
            );
          })}
        </div>

        <p className="text-justify  bottom-content">The content on this site is user generated and in no way reflects the views nor is endorsed by the owners of this site. You agree that the owner of this website is released of all liabilities. If you are offended by any material posted on this site you should exit immediately. This entire www.pinkspot.cc website, including its code, images, logos, and names are protected by copyright, and any infringement of said copyright will be prosecuted to the fullest extent of the law. By entering the website you acknowledge and agree to the above and agree to our terms & conditions, rules, and privacy policy.
          All with links that will navigate to upon clicking the terms & conditions, rules, and privacy policy.</p>
      </div>


      <div className="modal" id="myModal" style={{ display: `${modalactive}` }}>
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h4 className="modal-title">
                <img
                  className="logo"
                  src={require("../img/logo.png")}
                  alt="sgdg"
                />
              </h4>
            </div>
            <div className="modal-body">
              {localStorage.getItem("agreemodal")}
              <h6>As condition of your use of PinkSpot, you agree to the following:</h6>
              <ul style={{ listStyleType: "circle" }}>
                <li>I am at least 18 years of age - or of legal age in the country in which I reside.</li>
                <li> I will not post any material that exploits minors or in any way constitutes or assists in human trafficking.</li>
                <li>I will not post or produce content which violates Pinkspot guidelines (i.e. using images of genitalia, real or simulated sex acts as my profile picture).</li>
                <li>I have read and agree to observe the Terms of Service, Privacy Policy, ad posting guidelines and Rules not specifically addressed herein.</li>
              </ul>
            </div>
            <div className="modal-footer">
              <button className="btn btn-model" onClick={() => setModalHide()}>
                {" "}
                Agree
              </button>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
};

export default Home;