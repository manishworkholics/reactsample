import React, { useEffect, useState, useRef } from 'react'
import Navbar from './../Template/Navbar';
import Footer from './../Template/Footer';
import Conversation from '../Template/Conversation';
import ChatBox from '../Template/ChatBox';
import { Link } from "react-router-dom";
import { io } from "socket.io-client";

const Message = () => {
    const socket = useRef();
    const userid = sessionStorage.getItem('userid')
    const [chats, setChats] = useState([]);
    const [currentChat, setCurrentChat] = useState(null);
    const [onlineUsers, setOnlineUsers] = useState([]);
    const [sendMessage, setSendMessage] = useState(null);
    const [receivedMessage, setReceivedMessage] = useState(null);

    useEffect(() => {
        const getChats = () => {
            fetch(`https://api.pinkspot.cc/chat/${userid}`)
                .then(response => {
                    return response.json()
                }).then(data => {
                    setChats(data)
                })
        }
        getChats();
    }, [userid]);

    // Connect to Socket.io
    useEffect(() => {
        // socket.current = io("ws://localhost:9900");
        socket.current = io("ws://206.189.130.102:9900");
        socket.current.emit("new-user-add", userid);
        socket.current.on("get-users", (users) => {
            setOnlineUsers(users);
        });
    }, [userid]);

    // Send Message to socket server
    useEffect(() => {
        if (sendMessage !== null) {
            socket.current.emit("send-message", sendMessage);
        }
    }, [sendMessage]);

    // Get the message from socket server
    useEffect(() => {
        socket.current.on("recieve-message", (data) => {
            console.log(data)
            setReceivedMessage(data);
        }

        );
    }, []);


    const checkOnlineStatus = (chat) => {
        const chatMember = chat.members.find((member) => member !== userid);
        const online = onlineUsers.find((user) => user.userId === chatMember);
        return online ? true : false;
    };

    return (
        <>
            <Navbar />
            <nav className="navbar navbar-expand-sm bg-light">

                <div className="container">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <Link className="nav-link" to='/mypost'>My Ads</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to='/my-message'>My Messages</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to='/my-favorites'>My Favorites</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to='/user-profile'>My Profile</Link>
                        </li>
                    </ul>
                </div>

            </nav>


            <div className="Chat">
                {/* Left Side */}
                <div className="Left-side-chat">

                    <div className="Chat-container">
                        <h2>Chats</h2>
                        <div className="Chat-list">
                            {chats.map((chat) => (
                                <div
                                    onClick={() => {
                                        setCurrentChat(chat);
                                    }}
                                >
                                    <Conversation
                                        data={chat}
                                        currentUser={userid}
                                        online={checkOnlineStatus(chat)}
                                    />
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Right Side */}

                <div className="Right-side-chat">
                    <div style={{ width: "20rem", alignSelf: "flex-end" }}>

                    </div>
                    <ChatBox
                        chat={currentChat}
                        currentUser={userid}
                        setSendMessage={setSendMessage}
                        receivedMessage={receivedMessage}
                    />
                </div>
            </div>
            <Footer />
        </>
    )
}

export default Message