import React from "react";
import Header from './../Template/Header'
import Footer from './../Template/Footer'
const PageNotFound = () => {
	return (
		<>
			<Header />
			<div className="feature" id="content">
				<div id="content-inner">
					<main id="contentbar">
						<div className="article">
							<h1 className="center">Oops page not found</h1>
						</div>
					</main>
					<div className="clr"></div>
				</div>
			</div>
			<Footer />
		</>
	);
}

export default PageNotFound;