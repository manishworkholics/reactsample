import React, { useEffect, useState, useRef } from 'react'
import { useNavigate } from "react-router-dom";


const Otp = () => {
    const [otp1, setOtp1] = useState("");
    const [otp2, setOtp2] = useState("");
    const [otp3, setOtp3] = useState("");
    const [otp4, setOtp4] = useState("");
    const [otp5, setOtp5] = useState("");
    const [otp6, setOtp6] = useState("");

    const otpInputs = [useRef(), useRef(), useRef(), useRef(), useRef(), useRef()];
    const handleOtpChange = (index, value) => {
        if (value && index < otpInputs.length - 1) {
            otpInputs[index + 1].current.focus();
        }
    };
    const [userid, setuserid] = useState('');
    sessionStorage.getItem('userid');

    const navigate = useNavigate();



    const submitData = async (e) => {
        e.preventDefault();

        const combineotp = otp1 + otp2 + otp3 + otp4 + otp5 + otp6;

        const data = fetch(`https://api.pinkspot.cc/api/v1/users/verifyemailotp/${userid}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ otp: combineotp })
        });

        const response = await data;

        if (response.status === 401 || !response) {
            window.alert("otp not match");
        } else {
            window.alert("OTP MATCH");
            navigate('/login');
        }
    }


    useEffect(() => {
        setuserid(localStorage.getItem('userid'));
    }, [])



    return (
        <>
            <div className='container-fluid'>
                <div className='row mt-4'>
                    <div className='col-md-1'></div>
                    <div className='col-md-5'>
                        <div className='otp-box'>
                            <h4>OTP</h4>
                            <h6>Enter verification code</h6>
                            <p>we sent a 6 digit code to Email</p>
                            <form onSubmit={submitData}>
                                <input
                                    type="text"
                                    maxLength="1"
                                    value={otp1}
                                    onChange={(e) => {
                                        setOtp1(e.target.value);
                                        handleOtpChange(0, e.target.value);
                                    }}
                                    ref={otpInputs[0]}
                                />
                                <input
                                    type="text"
                                    maxLength="1"
                                    value={otp2}
                                    onChange={(e) => {
                                        setOtp2(e.target.value);
                                        handleOtpChange(1, e.target.value);
                                    }}
                                    ref={otpInputs[1]}
                                />
                                <input
                                    type="text"
                                    maxLength="1"
                                    value={otp3}
                                    onChange={(e) => {
                                        setOtp3(e.target.value);
                                        handleOtpChange(2, e.target.value);
                                    }}
                                    ref={otpInputs[2]}
                                />

                                <input
                                    type="text"
                                    maxLength="1"
                                    value={otp4}
                                    onChange={(e) => {
                                        setOtp4(e.target.value);
                                        handleOtpChange(3, e.target.value);
                                    }}
                                    ref={otpInputs[3]}
                                />
                                <input
                                    type="text"
                                    maxLength="1"
                                    value={otp5}
                                    onChange={(e) => {
                                        setOtp5(e.target.value);
                                        handleOtpChange(4, e.target.value);
                                    }}
                                    ref={otpInputs[4]}
                                />
                                <input
                                    type="text"
                                    maxLength="1"
                                    value={otp6}
                                    onChange={(e) => {
                                        setOtp6(e.target.value);
                                        handleOtpChange(5, e.target.value);
                                    }}
                                    ref={otpInputs[5]}
                                />
                                {/* <button className='otp-btn'>Resend code by SMS </button> */}
                                <button className='otp-btn mt-2' type="submit">SUBMIT</button>
                            </form>

                        </div>
                    </div>
                    <div className='col-md-1'></div>
                    <div className='col-md-5'>
                        <div className='signup-box'>

                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Otp