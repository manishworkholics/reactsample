import React, { useState, useEffect } from "react";

import { Link, useNavigate } from "react-router-dom";
import Helmet from "react-helmet";
const Login = () => {
  const navigate = useNavigate();
  const [data, setData] = useState({ email: "", password: "" });
  const [isChecked, setIsChecked] = useState(() => !!localStorage.checkbox);
  const [seo, setSeo] = useState();

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setData({ ...data, [name]: value });
  };
  const Submit = async (e) => {
    e.preventDefault();
    const { email, password } = data;

    if (isChecked && email !== "") {
      localStorage.setItem("email", email);
      localStorage.setItem("password", password);
      localStorage.checkbox = isChecked ? "1" : "";
    }

    const fetchdata = fetch("https://api.pinkspot.cc/api/v1/users/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const response = await fetchdata;
    const res = await response.json();

    if (response.status === 200) {
      if (res.userdata.status === "DELETE") {
        alert('Account Deleted');
        return;
      }
      if (res.userdata.isVerified) {
        sessionStorage.setItem("token", res.token);
        sessionStorage.setItem("userid", res.userdata._id);
        navigate("/");
      } else {
        localStorage.setItem("userid", res.userdata._id);
      }
    } else {
      alert("Invalid Credentials");
    }
  };

  const getseoetail = () => {
    fetch(`https://api.pinkspot.cc/api/v1/pages/getPageById/6532645aefe8c2f29fdce97d`)
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        setSeo(data);
      });
  };

  useEffect(() => {
    getseoetail();
  }, []);

  useState(() => {
    const email = localStorage.email;
    const password = localStorage.password;
    setData({ email: email, password: password });
  }, []);

  return (
    <>
      <Helmet>
        <title>{seo?.data?.seotitle}</title>
        <meta name="description" content={seo?.data?.seodescription} />
        <meta name="keywords" content={seo?.data?.seokeyword} />
        <meta name="author" content="PINK SPOT" />
        <meta property="og:title" content={seo?.data?.seotitle} />
        <meta property="og:description" content={seo?.data?.seodescription} />
        <meta property="og:image" content={seo?.data?.seoimageurl} />
        <meta property="og:url" content={`https://pinkspot.cc/login`} />
      </Helmet>

      <div className="container-fluid">
        <div className="row mt-2">
          <div className="col-md-1"></div>
          <div className="col-md-4">
            <div className="signup-boxone">
              <img src={require("../img/logo.png")} alt="sgdg" />
              <h4 className="text-center">Log In</h4>
              <div className="form">
                <form onSubmit={Submit}>
                  <div className="mb-3 mt-3">
                    <label htmlFor="email" className="form-label"> Email </label>
                    <input type="email" className="form-control" id="email" name="email" value={data.email} onChange={handleChange} required />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="pwd" className="form-label"> Password </label>
                    <input type="password" className="form-control" id="password" name="password" value={data.password} onChange={handleChange} required />
                  </div>

                  <input type="checkbox" checked={isChecked} name="lsRememberMe" onChange={(e) => setIsChecked(e.target.checked)} style={{ marginRight: '5px' }} />Remember me


                  <button type="submit" className="btn submit-btn">
                    Log In
                  </button>

                  <div className="text-center">
                    <Link className="login-link" to="/forgetpassword"> Forget Passwor </Link>
                    <p>Don’t have an account</p>

                    <Link className="login-link" to="/sign-up">  Sign Up </Link>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div className="col-md-2"></div>
          <div className="col-md-4">
            <div className="signup-box"></div>
            <div className="col-md-1"></div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
