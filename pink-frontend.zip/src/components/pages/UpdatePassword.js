import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const UpdatePassword = () => {
  const { id } = useParams(); //resettoken <<<

  const navigate = useNavigate();
  const [data, setData] = useState({ password: "", copassword: "", resettoken: id });

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;

    setData({ ...data, [name]: value });
  };

  const Submit = async (e) => {
    e.preventDefault();
    const { password, copassword } = data;
    if (password !== copassword) {
      alert('Password Not Match');
      return;
    }
    // https://api.pinkspot.cc/api/v1/users/login
    const fetchdata = fetch("http://206.189.130.102:3005/api/v1/users/updatepassword", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password, resettoken: id }),
    });

    const response = await fetchdata;
    await response.json();

    if (response.status === 200) {

      navigate("/pinkspot.cc");
    } else {
      alert("Invalid Credentials");
    }
  };
  return (
    <>
      <div className="container-fluid">
        <div className="row mt-2">
          <div className="col-md-1"></div>
          <div className="col-md-4">
            <div className="signup-boxone">
              <img src={require("../img/logo.png")} alt="sgdg" />
              <h4 className="text-center">Update Password</h4>
              <div className="form">
                <form onSubmit={Submit}>
                  <div className="mb-3">
                    <label htmlFor="pwd" className="form-label">
                      Password
                    </label>
                    <input
                      type="password"
                      className="form-control"
                      id="password"
                      name="password"
                      value={data.password}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="pwd" className="form-label">
                      Confirm Password
                    </label>
                    <input
                      type="password"
                      className="form-control"
                      id="password"
                      name="copassword"
                      value={data.copassword}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <button type="submit" className="btn submit-btn">
                    Update Password
                  </button>
                </form>
              </div>
            </div>
          </div>
          <div className="col-md-2"></div>
          <div className="col-md-4">
            <div className="signup-box"></div>
            <div className="col-md-1"></div>
          </div>
        </div>
      </div>
    </>
  );
};

export default UpdatePassword;
