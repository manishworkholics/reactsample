import React, { useState, useEffect } from 'react'
import Navbar from './../Template/Navbar'
import Footer from './../Template/Footer'
import { Link } from "react-router-dom";
import Preloader from '../Template/Preloader';
import TimeAgo from 'javascript-time-ago'
import en from 'javascript-time-ago/locale/en.json'

import Login from './Login'
const Favorites = () => {
    TimeAgo.setDefaultLocale(en.locale)
    TimeAgo.addLocale(en)
    const [spinner, setSpinner] = useState(false);
    const usertoken = sessionStorage.getItem('token')
    const userid = sessionStorage.getItem('userid')
    const [post, Setpost] = useState([{}]);
    const getpost = () => {
        setSpinner(true);
        fetch(`https://api.pinkspot.cc/api/v1/postad/getfavpostbyuserid/${userid}`)
            .then((response) => {
                return response.json();
            })
            .then((data) => {
                Setpost(data?.data);
                setSpinner(false);
            });
    };

    useEffect(() => {
        getpost();
    }, [])// eslint-disable-line react-hooks/exhaustive-deps

    if (!usertoken) {
        return <Login />
    }
    return (
        <>
            <Navbar />
            <nav className="navbar navbar-expand-sm bg-light">

                <div className="container">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <Link className="nav-link" to='/mypost'>My Ads</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to='/my-message'>My Messages</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to='/my-favorites'>My Favorites</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to='/user-profile'>My Profile</Link>
                        </li>
                    </ul>
                </div>

            </nav>
            <div className='container box-detail min-height'>

                <div className='row'>

                    <div className='col-md-9'>
                        {spinner && (
                            <Preloader />
                        )}
                        {post?.map((val, index) => {
                            return (
                                <>
                                    {val?.favouriteToPostid === null ? '' :
                                        <div className="categeory-card" key={index}>
                                            <div className="img-box">
                                                <img src={val?.favouriteToPostid?.image1} alt="" />
                                            </div>
                                            <div className="card-text" key={index}>
                                                <h6>{val?.favouriteToPostid?.title}</h6>

                                                <p>{val?.favouriteToPostid?.description}</p>
                                                {val?.favouriteToPostid?.isVerified !== true ? (
                                                    ""
                                                ) : (
                                                    <button className="btn">Verified</button>
                                                )}
                                                <Link to={`/profile/${val?.favouriteToPostid?.city.split(" ").join("-")}/${val?.favouriteToPostid?.slug}`} className='btn btn-warning'>View Ad</Link>
                                            </div>
                                        </div>
                                    }
                                </>
                            );
                        })}
                    </div>
                    <div className='col-md-3'></div>
                </div>

            </div>
            <Footer />
        </>
    )
}

export default Favorites