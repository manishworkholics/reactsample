import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const ForgetPassword = () => {
  const navigate = useNavigate();
  const [data, setData] = useState({ email: "" });

  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setData({ ...data, [name]: value });
  };
  const Submit = async (e) => {
    e.preventDefault();
    const { email } = data;

    const fetchdata = fetch(
      "http://206.189.130.102:3005/api/v1/users/forgetpassword",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      }
    );
    const response = await fetchdata;
    await response.json();

    if (response.status === 200) {
      alert("Please Check Your Email For  Password Link");
      navigate("/pinkspot.cc/");
    } else {
      alert("Invalid Credentials");
    }
  };
  return (
    <>
      <div className="container-fluid">
        <div className="row mt-2">
          <div className="col-md-1"></div>
          <div className="col-md-4">
            <div className="signup-boxone ">
              <img src={require("../img/logo.png")} alt="sgdg" />
              <h4 className="text-center">Forgot Password</h4>
              <div className="form">
                <form onSubmit={Submit}>
                  <div className="mb-3 mt-3">
                    <label htmlFor="email" className="form-label">
                      Email
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      id="email"
                      name="email"
                      value={data.email}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <button type="submit" className="btn submit-btn">
                    Forgot Password
                  </button>
                </form>
              </div>
            </div>
          </div>
          <div className="col-md-2"></div>
          <div className="col-md-4">
            <div className="signup-box"></div>
            <div className="col-md-1"></div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ForgetPassword;
