import React, { useEffect, useState } from "react";
import Navbar from './../Template/Navbar'
import { Link } from "react-router-dom";
import Footer from './../Template/Footer'

const Postadd = () => {
    const [category, Setcategory] = useState('')

    const getcategory = () => {
        fetch(`https://api.pinkspot.cc/api/v1/category/getallcategory`)
            .then(response => {
                return response.json()
            }).then(data => {
                Setcategory(data)
            })
    }
    useEffect(() => {
        getcategory()
        window.scrollTo({ behavior: 'smooth', top: 0 })
    }, [])

    return (
        <>
            <Navbar />
            <div className='container mt-5' style={{ height: 520 }}>
                <div className='row'>
                    <div className='col-md-2'></div>
                    <div className='col-md-8'>
                        {category.data?.map((val, index) => {
                            return (
                                <div className="dropdown dropend" key={index}>
                                    <button type="button" className="dropdown-btn text-capital" data-bs-toggle="dropdown" >
                                        <img className="material-symbols-outlined" src={val.iconname} alt="" />
                                        {val.name.charAt(0).toUpperCase() + val.name.slice(1).toLowerCase()}
                                    </button>

                                    <ul className="dropdown-menu">
                                        {val.subcategoriesId.map((val, index) => {
                                            return (
                                                <li key={index}><Link className="dropdown-item text-capital" to={`/${val.formid}`} state={{ category: val.categoryid, subcategoryid: val._id }}> {val.name}</Link></li>
                                            )
                                        })}
                                    </ul>
                                </div>
                            )
                        })}
                    </div>
                    <div className='col-md-2'></div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default Postadd