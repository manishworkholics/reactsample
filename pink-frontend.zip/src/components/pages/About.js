import React, { useEffect, useState } from 'react';
import Header from '../Template/Header'
import Footer from '../Template/Footer'

import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';

const About = () => {

  const [currentLocation, setCurrentLocation] = useState(null);
  const [selectedLocation, setSelectedLocation] = useState(null)

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setCurrentLocation({ lat: latitude, lng: longitude });
        },
        (error) => {
          console.error(error);
        }
      );
    } else {
      console.error("Geolocation is not supported by this browser.");
    }
  }, []);

  const handleMapClick = async () => {
    const lat = currentLocation.lat;
    const lng = currentLocation.lng;
    try {
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=AIzaSyC_tM21bck3SgTfv2iAzuCYY0pfRTeLlDQ`
      );
      const data = await response.json();

      if (data.results.length > 0) {
        const { address_components } = data.results[0];
        let areaName = '';
        let cityName = '';

        // Loop through address components to find the area and city names
        for (let component of address_components) {
          if (component.types.includes('sublocality_level_1')) {
            areaName = component.long_name;
          }
          if (component.types.includes('locality')) {
            cityName = component.long_name;
          }
        }

        setSelectedLocation({
          lat,
          lng,
          areaName,
          cityName,
        });
      }
    } catch (error) {
      console.error('Error fetching location details:', error);
    }
  };
  console.log(selectedLocation)
  return (
    <>
      <Header />
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <LoadScript googleMapsApiKey="AIzaSyC_tM21bck3SgTfv2iAzuCYY0pfRTeLlDQ">
              {currentLocation && (
                <GoogleMap
                  mapContainerStyle={{ height: '400px', width: '100%' }}
                  zoom={13}
                  center={currentLocation}
                >
                  <Marker position={currentLocation} />
                </GoogleMap>
              )}
              <button className='btn btn-danger' onClick={handleMapClick}>get area</button>
              <h6>{selectedLocation}</h6>
              <h6>{currentLocation?.lat}</h6>
              <h6>{currentLocation?.lng}</h6>
            </LoadScript>
          </div>
        </div>
      </div>
      <Footer />
    </>
  )
}

export default About