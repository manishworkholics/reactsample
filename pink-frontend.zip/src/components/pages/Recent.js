import React, { useEffect, useState } from 'react'
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import { Pagination } from "swiper";
import { Link } from "react-router-dom";

const Recent = () => {
    const [post, Setpost] = useState('')
    const getpost = () => {
        fetch(`https://api.pinkspot.cc/api/v1/postad/getallpostad_sort_desc`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ limit: "12" })
        })
            .then(response => {
                return response.json()
            }).then(data => {
                Setpost(data)
            })
    }
    useEffect(() => {
        getpost()
        window.scrollTo({ behavior: 'smooth', top: 0 })
    }, [])
    const onscroll = () => {
        window.scrollTo({ behavior: 'smooth', top: 0 })
    }

    return (
        <>

            <div className='recent'>
                <h6>Recent Ads by Other Users</h6>
                <div className='recent-pic'>
                    <Swiper
                        slidesPerView={5}
                        spaceBetween={30}
                        pagination={{
                            clickable: true,
                        }}
                        modules={[Pagination]}
                        className="mySwiper"
                    >
                        {post?.data?.map((val, index) => {
                            return (
                                <SwiperSlide><Link key={index} to={`/profile/${val?.city.split(" ").join("-")}/${val?.slug}`} onClick={onscroll}><img src={val.image1} alt="sgdg" /></Link></SwiperSlide>
                            )
                        })}


                    </Swiper>
                </div>
            </div>
        </>
    )
}

export default Recent

