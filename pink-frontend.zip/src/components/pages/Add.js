import React, { useState, useEffect } from 'react'
import Navbar from './../Template/Navbar'
import Footer from './../Template/Footer'
import TimeAgo from 'javascript-time-ago'
import en from 'javascript-time-ago/locale/en.json'
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/free-mode";
import "swiper/css/navigation";
import "swiper/css/thumbs";
import { FreeMode, Navigation, Thumbs } from "swiper";
import { useLocation } from 'react-router-dom'


const Add = () => {
    TimeAgo.setDefaultLocale(en.locale)
    TimeAgo.addLocale(en)
    const userid = sessionStorage.getItem('userid')
    const location = useLocation();
    const { data } = location.state;
    const [thumbsSwiper, setThumbsSwiper] = useState(null);

    const getreport = () => {
        fetch(`https://api.pinkspot.cc/api/v1/postad/reportpostad`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ userid: userid, postadid: data?._id })
        })
            .then(response => {
                return response.json()
            }).then(data => {

                window.alert(data.message);
            })
    }

    useEffect(() => {
        window.scrollTo({ behavior: 'smooth', top: 0 })
    }, [])// eslint-disable-line react-hooks/exhaustive-deps

    return (
        <>
            <Navbar />
            <div className='container'>
                <div className='row'>
                    <div className='col-md-8'>
                        <Swiper
                            style={{
                                "--swiper-navigation-color": "#fff",
                                "--swiper-pagination-color": "#fff",
                            }}
                            loop={true}
                            spaceBetween={10}
                            navigation={true}
                            thumbs={{ swiper: thumbsSwiper }}
                            modules={[FreeMode, Navigation, Thumbs]}
                            className="mySwiper2"
                        >
                            {data.image1 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image1} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image2 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image2} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image3 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image3} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image4 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image4} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image5 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image5} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image6 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image6} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image7 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image7} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image8 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image8} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image9 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image9} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image10 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image10} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image11 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image11} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image12 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image12} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image13 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image13} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image14 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image14} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image15 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image15} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image16 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image16} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image17 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image17} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image18 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image18} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image19 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image19} alt="sgdg" />
                            </SwiperSlide>}
                            {data.image20 !== "" && <SwiperSlide>
                                <img className='slider-small' src={data.image20} alt="sgdg" />
                            </SwiperSlide>}
                        </Swiper>
                        <Swiper
                            onSwiper={setThumbsSwiper}
                            loop={true}
                            spaceBetween={10}
                            slidesPerView={4}
                            freeMode={true}
                            watchSlidesProgress={true}
                            modules={[FreeMode, Navigation, Thumbs]}
                            className="mySwiper"
                        >
                            {data.image1 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image1} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image2 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image2} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image3 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image3} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image4 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image4} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image5 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image5} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image6 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image6} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image7 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image7} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image8 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image8} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image9 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image9} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image10 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image10} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image11 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image11} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image12 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image12} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image13 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image13} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image14 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image14} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image15 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image15} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image16 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image16} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image17 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image17} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image18 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image18} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image19 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image19} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                            {data.image20 !== "" && <SwiperSlide>
                                <img className='slider-box' src={data.image20} alt="sgdg" style={{ background: '#e7e7e7' }} />
                            </SwiperSlide>}
                        </Swiper>

                        <div className='profile-text-box'>
                            <div className='profile-text'>
                                {data.name && <div> {data.name && <h6>Name </h6>} <h5>{data.name} </h5></div>}
                                {<div> {data.availability && <h6>Availability </h6>}<h5>{data.availability} </h5></div>}
                                {data.availability && <div>{data.haircolour && <h6>Hair Colour </h6>}<h5>{data.haircolour}</h5></div>}
                                {data.type && <div>{data.type && <h6>type </h6>}<h5>{data.type}</h5></div>}
                                {data.listedby && <div>{data.listedby && <h6>listedby </h6>}<h5>{data.listedby}</h5></div>}
                                {data.totalfloors && <div>{data.totalfloors && <h6>totalfloors </h6>}<h5>{data.totalfloors}</h5></div>}
                                {data.facing && <div>{data.facing && <h6>facing </h6>}<h5>{data.facing}</h5></div>}
                                {data.price && <div>{data.price && <h6>Hourly Rate $</h6>}<h5>{data.price}</h5></div>}
                            </div>
                            <div className='profile-text'>
                                {data.age && <div>{data.age && <h6>Age </h6>}<h5>{data.age} </h5></div>}
                                {data.height && <div> {data.height && <h6>Height </h6>}<h5>{data.height}</h5></div>}
                                {data.eyecolour && <div>{data.eyecolour && <h6>Eye Colour </h6>}<h5>{data.eyecolour}</h5></div>}
                                {data.email && <div>{data.email && <h6>email </h6>}<h5>{data.email}</h5></div>}
                                {data.bedroom && <div>{data.bedroom && <h6>bedroom </h6>}<h5>{data.bedroom}</h5></div>}
                                {data.superbuiltuparea && <div>{data.superbuiltuparea && <h6>superbuiltuparea </h6>}<h5>{data.superbuiltuparea}</h5></div>}
                                {data.floorno && <div>{data.floorno && <h6>floorno </h6>}<h5>{data.floorno}</h5></div>}
                                {data.projectname && <div>{data.projectname && <h6>projectname </h6>}<h5>{data.projectname}</h5></div>}
                            </div>
                            <div className='profile-text'>
                                {data.city && <div>{data.city && <h6>City </h6>}<h5>{data.city} </h5></div>}
                                {data.weight && <div> {data.weight && <h6>Weight </h6>}<h5>{data.weight}</h5></div>}

                                {data.bathroom && <div>{data.bathroom && <h6>bathroom</h6>}<h5>{data.bathroom}</h5></div>}
                                {data.carpetarea && <div>{data.carpetarea && <h6>carpetarea</h6>}<h5>{data.carpetarea}</h5></div>}
                                {data.carparking && <div>{data.carparking && <h6>carparking</h6>}<h5>{data.carparking}</h5></div>}
                            </div>
                            <div className='profile-text'>
                                {data.ethicity && <div>{data.ethicity && <h6>Ethnicity </h6>}<h5>{data.ethicity}</h5></div>}
                                {data.bodystatus && <div> {data.bodystatus && <h6>Body Stats </h6>}<h5>{data.bodystatus}</h5></div>}
                                {data.phone && <div>{data.phone && <h6>Contact Number </h6>}<h5>{data.phone}</h5></div>}
                                {data.furnishing && <div>{data.furnishing && <h6>furnishing </h6>}<h5>{data.furnishing}</h5></div>}
                                {data.constructionstatus && <div>{data.constructionstatus && <h6>construction </h6>}<h5>{data.constructionstatus}</h5></div>}
                                {data.maintenance && <div>{data.maintenance && <h6>maintenance </h6>}<h5>{data.maintenance}</h5></div>}
                            </div>
                        </div>
                        <div className='profile-text-box'>
                            <div className='profile-text'>
                                <h4>{data.title}</h4>
                                <p></p>
                                <p>{data.description}</p>
                            </div>
                            <div>
                                <button className='btn'><img src={require("../img/eye.png")} alt="sgdg" /> {data?.numViews} visits</button>
                                <button className='btn' onClick={() => getreport()}><img src={require("../img/flag.png")} alt="sgdg" />Report Add</button>
                            </div>
                        </div>
                    </div>
                    <div className='col-md-4'></div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default Add