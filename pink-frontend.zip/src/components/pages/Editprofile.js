import React, { useState } from 'react'
import Navbar from './../Template/Navbar'
import Footer from './../Template/Footer'
import { Link, useLocation } from "react-router-dom";
import Login from './Login'

const Editprofile = () => {
    const location = useLocation();
    const { data } = location.state
    const usertoken = sessionStorage.getItem('token')
    const userid = sessionStorage.getItem('userid')
    const [file1, setFile1] = useState(data?.image);
    const [user, setUser] = useState({ name: data?.name, email: data?.email, phone: data?.phone, streetaddress: data?.streetaddress });
    let name, value
    const HandleInput = (e) => {
        name = e.target.name;
        value = e.target.value;
        setUser({ ...user, [name]: value });
    }
    const handleSubmit = () => {
        const postURL = `https://api.pinkspot.cc/api/v1/users/updateprofile/${userid}`
        const { name, email, phone, password, streetaddress } = user;
        fetch(postURL, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, email, phone, password, streetaddress, image: file1 })

        })
            .then(res => {
                return res.json();
            }).then(data => {
                window.alert("profile updated");
            })
    }
    function handleChange1(e) {
        var formdata = new FormData();
        formdata.append("image", e?.target?.files[0]);
        var requestOptions = {
            method: 'POST',
            body: formdata,
            redirect: 'follow'
        };
        fetch("https://api.pinkspot.cc/upload", requestOptions)
            .then(response => response.json())
            .then(result => setFile1(result?.data?.url))
    }
    if (!usertoken) {
        return <Login />
    }
    console.log(user)
    return (
        <>
            <Navbar />

            <nav className="navbar navbar-expand-sm bg-light">

                <div className="container">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <Link className="nav-link" to='/mypost'>My Ads</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to='/my-message'>My Messages</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to='/my-favorites'>My Favorites</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to='/user-profile'>My Profile</Link>
                        </li>
                    </ul>
                </div>

            </nav>
            <div className='container my-3'>
                <div className='row'>
                    <div className='col-md-6'>
                        <div >
                            <h5>Edit profile</h5>
                            <p>Only your name and profile photo will be displayed on your public profile.</p>
                        </div>
                    </div>
                    <div className='col-md-4'></div>
                    <div className='col-md-2'>
                        <Link className='view-profile-btn' to='/user-profile'>View my profile</Link>
                    </div>
                </div>
            </div>
            <form>
                <div className='container'>
                    <div className='row'>
                        <div className='col-md-4'>
                            <div className="mb-3 mt-3">
                                <label htmlFor="name" className="form-label">Name</label>
                                <input type="text" className="form-control" id="name" name="name" value={user.name} onChange={HandleInput} />
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="name" className="form-label">Password</label>
                                <input type="Password" className="form-control" id="Password" name="password" value={user.password} onChange={HandleInput} />
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="phone" className="form-label">Phone number (optional)</label>
                                <input type="Number" className="form-control" id="phone" name="phone" value={user.phone} onChange={HandleInput} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className="mb-3 mt-3">
                                <label htmlFor="email" className="form-label">Email address</label>
                                <input type="email" className="form-control" id="email" name="email" value={user.email} onChange={HandleInput} />
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="email" className="form-label">Street address and/or postal code (optional)</label>
                                <input type="text" className="form-control" id="adress" name="streetaddress" value={user.streetaddress} onChange={HandleInput} />
                            </div>
                        </div>
                        <div className='col-md-4'>
                            <div className='update-user-card'>
                                <div className='card-inner'></div>

                                {file1 ? <img className='card-img' src={file1} alt='xyz' /> :
                                    <img className='card-img' src={require("../img/user.jpg")} alt="sgdg" />}
                                <h6>Upload your profile photo</h6>
                                <input type="file" id="file" name="filename" onChange={handleChange1} />
                            </div>
                        </div>
                    </div>
                </div>
            </form >

            <div className='container my-5'>
                <div className='row'>
                    <div className='col-md-4'>
                        <div >
                            <button className='save-btn-profile' onClick={() => handleSubmit()}>Save changes</button>
                        </div>
                    </div>
                    <div className='col-md-4'></div>
                    <div className='col-md-4'></div>
                </div>
            </div>

            <Footer />
        </>
    )
}

export default Editprofile