import React, { useState, useEffect } from 'react'
import Navbar from './../Template/Navbar'
import Footer from './../Template/Footer'
import { Link } from "react-router-dom";
import Preloader from '../Template/Preloader';
import TimeAgo from 'javascript-time-ago'
import ReactTimeAgo from 'react-time-ago'
import en from 'javascript-time-ago/locale/en.json'
import Login from './Login'

const Userprofile = () => {

    TimeAgo.setDefaultLocale(en.locale)
    TimeAgo.addLocale(en)
    const [spinner, setSpinner] = useState(false);
    const usertoken = sessionStorage.getItem('token')
    const userid = sessionStorage.getItem('userid')
    const [post, Setpost] = useState('')
    const [user, Setuser] = useState('')
    const [deleteid, Setdeleteid] = useState('')

    const getpost = () => {
        setSpinner(true);
        fetch(`https://api.pinkspot.cc/api/v1/postad/getpostadby_user_id/${userid}`)
            .then(response => {
                return response.json()
            }).then(data => {
                Setpost(data)
                setSpinner(false);
            })
    }
    const getuser = () => {
        fetch(`https://api.pinkspot.cc/api/v1/users/${userid}`)
            .then(response => {
                return response.json()
            }).then(data => {
                Setuser(data)
            })
    }
    function deleteUser(_id) {
        fetch(`https://api.pinkspot.cc/api/v1/postad/deletepostadby_single_id/${_id}`, {
            method: "DELETE"
        }).then((result) => {
            result.json().then((res) => {
                getpost()
            })
        })
    }
    useEffect(() => {
        getpost();
        getuser();
    }, [])// eslint-disable-line react-hooks/exhaustive-deps

    if (!usertoken) {
        return <Login />
    }

    return (
        <>
            <Navbar />
            <nav className="navbar navbar-expand-sm bg-light">

                <div className="container">
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <Link className="nav-link" to='/mypost'>My Ads</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to='/my-message'>My Messages</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to='/my-favorites'>My Favorites</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to='/user-profile'>My Profile</Link>
                        </li>
                    </ul>
                </div>

            </nav>
            <div className='container box-detail min-height'>

                <div className='row'>
                    <div className='col-md-3'>
                        <div className='user-card'>
                            <div className='card-inner'></div>
                            {user?.image !== "" ? <img className='card-img' src={user?.image} alt="sgdg" /> : <img className='card-img' src={require("../img/user.jpg")} alt="sgdg" />}
                            <h5>{user?.name}</h5>
                            <Link className="btn mb-1" to='/edit-profile' state={{ data: user }}>Edit Profile</Link>
                        </div>
                    </div>
                    <div className='col-md-9'>
                        <h5 className='listing'>Listings</h5>
                        {spinner && (
                            <Preloader />
                        )}
                        {post.data?.map((val, index) => {
                            return (
                                <div className='categeory-card' id={index}>
                                    <div className='img-box'><img src={val.image1} alt="sgdg" /></div>
                                    <div className='card-text' id={index}>
                                        <h6>{val.title}</h6>
                                        <span className='ml-2'>Posted <ReactTimeAgo date={val.createdAt} locale="en-US" /></span> |<span className='mx-2'>City: {val.city}</span>
                                        <p>{val.description}</p>
                                        {val.isVerified !== true ? '' : <button className='btn'>Verified</button>}
                                        <button className='btn btn-danger' data-bs-toggle="modal" data-bs-target="#myModal" onClick={() => { Setdeleteid(val._id) }}>Delete</button>
                                        <Link to='/add' state={{ data: val }} className='btn btn-warning'>Detail</Link>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>
            <Footer />
            <div className="modal fade" id="myModal">
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div className="modal-body">
                            Do You Want To Delete Permanently
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="nav-btn" data-bs-dismiss="modal" onClick={() => deleteUser(deleteid)}>Yes</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Userprofile