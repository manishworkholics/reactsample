import React, { useState, useEffect } from "react";
import Helmet from "react-helmet";
import Header from "./../Template/Header";
import Footer from "./../Template/Footer";

const Contactus = () => {
  const [seo, setSeo] = useState();
  const getseoetail = () => {
    fetch(`https://api.pinkspot.cc/api/v1/pages/getPageById/65324d65fbbcd6fe76c2a22d`)
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        setSeo(data);
      });
  };

  useEffect(() => {

    getseoetail();

  }, []);
  return (
    <div >
      <Helmet>
        <title>{seo?.data?.seotitle}</title>
        <meta name="description" content={seo?.data?.seodescription} />
        <meta name="keywords" content={seo?.data?.seokeyword} />
        <meta name="author" content="PINK SPOT" />
        <meta property="og:title" content={seo?.data?.seotitle} />
        <meta property="og:description" content={seo?.data?.seodescription} />
        <meta property="og:image" content={seo?.data?.seoimageurl} />
        <meta property="og:url" content={`https://pinkspot.cc/Contact-us`} />
      </Helmet>
      <Header />
      <div className='container-fluid  term-condition'>
        <div className='row'>
          <div className='col-md-12 term-background'>
            <h3 className='text-center'>Support / Contact US</h3>
          </div>
        </div>
      </div>




      <div className='container mt-3' style={{ minHeight: '30vh' }}>
        <div className='row'>
          <div className='col-md-12'>
            <h3 className='text-center'>For any support related issues please contact <span className='text-primary'>support@pinkspot.cc</span> </h3>

          </div>
        </div>
      </div>



      <Footer />
    </div>
  )
}

export default Contactus