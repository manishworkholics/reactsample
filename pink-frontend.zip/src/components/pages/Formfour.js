import React, { useState } from 'react';
import Header from './../Template/Header'
import Footer from './../Template/Footer'
import { useLocation } from 'react-router-dom'
import { useNavigate } from 'react-router-dom';

const Formthree = () => {
    const [province, Setprovince] = useState('')
    const [data, Setdata] = useState('')

    const [file1, setFile1] = useState("");
    const [file2, setFile2] = useState("");
    const [file3, setFile3] = useState("");
    const [file4, setFile4] = useState("");
    const [file5, setFile5] = useState("");
    const [file6, setFile6] = useState("");
    const [file7, setFile7] = useState("");
    const [file8, setFile8] = useState("");
    const [file9, setFile9] = useState("");
    const [file10, setFile10] = useState("");
    const [file11, setFile11] = useState("");
    const [file12, setFile12] = useState("");
    const [file13, setFile13] = useState("");
    const [file14, setFile14] = useState("");
    const [file15, setFile15] = useState("");
    const [file16, setFile16] = useState("");
    const [file17, setFile17] = useState("");
    const [file18, setFile18] = useState("");
    const [file19, setFile19] = useState("");
    const [file20, setFile20] = useState("");

    function handleChange1(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile1(result?.data?.url))
            }
        }
    }
    function handleChange2(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile2(result?.data?.url))
            }
        }
    }
    function handleChange3(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile3(result?.data?.url))
            }
        }
    }
    function handleChange4(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile4(result?.data?.url))
            }
        }
    }
    function handleChange5(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile5(result?.data?.url))
            }
        }
    }
    function handleChange6(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile6(result?.data?.url))
            }
        }
    }
    function handleChange7(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile7(result?.data?.url))
            }
        }
    }
    function handleChange8(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile8(result?.data?.url))
            }
        }
    }
    function handleChange9(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile9(result?.data?.url))
            }
        }
    }
    function handleChange10(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile10(result?.data?.url))
            }
        }
    }
    function handleChange11(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile11(result?.data?.url))
            }
        }
    }
    function handleChange12(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile12(result?.data?.url))
            }
        }
    }
    function handleChange13(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile13(result?.data?.url))
            }
        }
    }
    function handleChange14(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile14(result?.data?.url))
            }
        }
    }
    function handleChange15(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile15(result?.data?.url))
            }
        }
    }
    function handleChange16(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile16(result?.data?.url))
            }
        }
    }
    function handleChange17(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile17(result?.data?.url))
            }
        }
    }
    function handleChange18(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile18(result?.data?.url))
            }
        }
    }
    function handleChange19(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile19(result?.data?.url))
            }
        }
    }
    function handleChange20(e) {
        const file = e.target.files[0];
        if (file) {
            const fileSize = file.size;
            const maxSize = 1024*1024*1024;
            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit.');
            } else {
                var formdata = new FormData();
                formdata.append("image", e?.target?.files[0]);
                var requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };
                fetch("https://api.pinkspot.cc/upload", requestOptions)
                    .then(response => response.json())
                    .then(result => setFile20(result?.data?.url))
            }
        }
    }

    const getprovince = () => {
        fetch(`https://api.pinkspot.cc/api/v1/getallprovince`)
            .then(response => {
                return response.json()
            }).then(data => {
                Setprovince(data)
            })
    }
    const getcity = (e) => {
        const id = e.target.value;
        fetch(`https://api.pinkspot.cc/api/v1/getallcity/${id}`)
            .then(response => {
                return response.json()
            }).then(data => {
                Setdata(data)
            })
    }
    const location = useLocation();
    const { category, subcategoryid } = location.state;
    const userid = sessionStorage.getItem('userid')
    const navigate = useNavigate();

    const [user, setUser] = useState({ title: "", description: "",city:"", address: "", phone: "", email: "", type: "", bedroom: "", bathroom: "", furnishing: "", constructionstatus: "", listedby: "", superbuiltuparea: "", carpetarea: "", maintenance: "", totalfloors: "", floorno: "", carparking: "", facing: "", projectname: "" });

    let name, value
    const HandleInput = (e) => {
        console.log(e)
        name = e.target.name;
        value = e.target.value;
        setUser({ ...user, [name]: value });
    }

    const PostData = async (e) => {
        e.preventDefault();
        const { title, description,city, type, bedroom, bathroom, furnishing, constructionstatus, listedby, superbuiltuparea, carpetarea, maintenance, totalfloors, floorno, carparking, facing, projectname } = user;
        const res = fetch("https://api.pinkspot.cc/api/v1/postad/createpostad", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ postbyuserid: userid, category: category, subcategoryid: subcategoryid, title: title, description: description,city:city, type: type, bedroom: bedroom, bathroom: bathroom, furnishing: furnishing, constructionstatus: constructionstatus, listedby: listedby, superbuiltuparea: superbuiltuparea, carpetarea: carpetarea, maintenance: maintenance, totalfloors: totalfloors, floorno: floorno, carparking: carparking, facing: facing, projectname: projectname, image1: file1, image2: file2, image3: file3, image4: file4, image5: file5, image6: file6, image7: file7, image8: file8, image9: file9, image10: file10, image11: file11, image12: file12, image13: file13, image14: file14, image15: file15, image16: file16, image17: file17, image18: file18, image19: file19, image20: file20 })
        });
        const data = await res;

        if (data.status === 403 || !data) {
            window.alert(data.message);
        } else {
            window.alert("Ad Posted Successfully");
        }
        navigate('/mypost');
    }
    useEffect(() => {
        getprovince();
    }, []);
    return (
        <>
            <Header />
            <div className='container mt-5'>
                <div className='row'>
                    <div className='col-md-12'>
                        <h6 className='post-heading text-center'>Post your Ad</h6>
                    </div>
                </div>
            </div>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-1'></div>
                    <div className='col-md-10 post-form-border'>
                        <form className='add-post' onSubmit={PostData} action="/">
                            <div className="mb-3 mt-3">
                                <label htmlFor="type" className="form-label">Type*</label><br />
                                <button className='type-btn' name="type" onClick={HandleInput}>Apartments</button>
                                <button className='type-btn' name="type" onClick={HandleInput}>Builder Floors</button>
                                <button className='type-btn' name="type" onClick={HandleInput}>Farm Houses</button>
                                <button className='type-btn' name="type" onClick={HandleInput}>Houses & Villas</button>
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="bedroom" className="form-label">Bedrooms</label><br />
                                <button className='type-btn' name="bedroom" onClick={HandleInput}>1</button>
                                <button className='type-btn' name="bedroom" onClick={HandleInput}>2</button>
                                <button className='type-btn' name="bedroom" onClick={HandleInput}>3</button>
                                <button className='type-btn' name="bedroom" onClick={HandleInput}>4</button>
                                <button className='type-btn' name="bedroom" onClick={HandleInput}>4+</button>
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="bathroom" className="form-label">Bathrooms</label><br />
                                <button className='type-btn' name="bathroom" onClick={HandleInput}>1</button>
                                <button className='type-btn' name="bathroom" onClick={HandleInput}>2</button>
                                <button className='type-btn' name="bathroom" onClick={HandleInput}>3</button>
                                <button className='type-btn' name="bathroom" onClick={HandleInput}>4</button>
                                <button className='type-btn' name="bathroom" onClick={HandleInput}>4+</button>
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="furnishing" className="form-label">Furnishing</label><br />
                                <button className='type-btn' name="furnishing" onClick={HandleInput}>Furnished</button>
                                <button className='type-btn' name="furnishing" onClick={HandleInput}>Semi-Furnished</button>
                                <button className='type-btn' name="furnishing" onClick={HandleInput}>Unfurnished</button>

                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="constructionstatus" className="form-label">Construction Status</label><br />
                                <button className='type-btn' name="constructionstatus" onClick={HandleInput}>New Launch</button>
                                <button className='type-btn' name="constructionstatus" onClick={HandleInput}>Ready to Move</button>
                                <button className='type-btn' name="constructionstatus" onClick={HandleInput}>Under Construction</button>
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="listedby" className="form-label">Listed by</label><br />
                                <button className='type-btn' name="listedby" onClick={HandleInput}>Builder</button>
                                <button className='type-btn' name="listedby" onClick={HandleInput}>Dealer</button>
                                <button className='type-btn' name="listedby" onClick={HandleInput}>Owner</button>
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="superbuiltuparea" className="form-label">Super Builtup area (ft²) *</label>
                                <input type="text" className="form-control" id="superbuiltuparea" name="superbuiltuparea" onChange={HandleInput} />
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="carpetarea" className="form-label">Carpet Area (ft²) *</label>
                                <input type="text" className="form-control" id="carpetarea" name="carpetarea" onChange={HandleInput} />
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="maintenance" className="form-label">Maintenance (Monthly)</label>
                                <input type="text" className="form-control" id="maintenance" name="maintenance" onChange={HandleInput} />
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="totalfloors" className="form-label">Total Floors</label>
                                <input type="text" className="form-control" id="totalfloors" name="totalfloors" onChange={HandleInput} />
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="floorno" className="form-label">Floor No</label>
                                <input type="text" className="form-control" id="floorno" name="floorno" onChange={HandleInput} />
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="carparking" className="form-label">Car Parking</label><br />
                                <button className='type-btn' name="carparking" onClick={HandleInput}>1</button>
                                <button className='type-btn' name="carparking" onClick={HandleInput}>2</button>
                                <button className='type-btn' name="carparking" onClick={HandleInput}>3</button>
                                <button className='type-btn' name="carparking" onClick={HandleInput}>4</button>
                                <button className='type-btn' name="carparking" onClick={HandleInput}>4+</button>
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="facing" className="form-label">Facing</label>
                                <input type="text" className="form-control" id="facing" name="facing" onChange={HandleInput}/>
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="projectname" className="form-label">Project Name</label>
                                <input type="text" className="form-control" id="projectname" name="projectname" onChange={HandleInput}/>
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="title" className="form-label">Ad title *</label>
                                <input type="text" className="form-control" id="title" name="title" onChange={HandleInput}/>
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="description" className="form-label">Description *</label>
                                <input type="text" className="form-control" id="description" name="description" onChange={HandleInput}/>
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="name" className="form-label">Province*</label>
                                <select className="form-select" onChange={getcity}>
                                    <option>Select Province</option>
                                    {province?.data?.map((val, index) => {
                                        return (
                                            <option key={index} value={val._id}>{val.name}</option>
                                        )
                                    })}
                                </select>
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="name" className="form-label">City*</label>
                                <select className="form-select" name='city' onChange={HandleInput}>
                                    <option>Select City</option>
                                    {data?.data?.map((val, index) => {
                                        return (
                                            <option key={index} value={val.name}>{val.name}</option>
                                        )
                                    })}
                                </select>
                            </div>
                            <div className="mb-3 mt-3">
                                <label htmlFor="price" className="form-label">Price*</label>
                                <input type="text" className="form-control" id="price" name="price" onChange={HandleInput}/>
                            </div>
                            <div className="mb-3 mt-3 upload-photo">
                                <h6>UPLOAD UP TO 20 PHOTOS</h6>
                                <span className='text-danger'>(max 30 mb for each photo only)</span>
                                <div className='row mt-3'>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange1} />
                                            <img src={file1} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange2} />
                                            <img src={file2} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange3} />
                                            <img src={file3} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange4} />
                                            <img src={file4} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange5} />
                                            <img src={file5} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange6} />
                                            <img src={file6} alt='xyz' />
                                        </div>
                                    </div>

                                </div>
                                <div className='row mt-3'>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange7} />
                                            <img src={file7} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange8} />
                                            <img src={file8} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange9} />
                                            <img src={file9} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange10} />
                                            <img src={file10} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange11} />
                                            <img src={file11} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange12} />
                                            <img src={file12} alt='xyz' />
                                        </div>
                                    </div>
                                </div>
                                <div className='row mt-3'>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange13} />
                                            <img src={file13} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange14} />
                                            <img src={file14} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange15} />
                                            <img src={file15} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange16} />
                                            <img src={file16} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange17} />
                                            <img src={file17} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange18} />
                                            <img src={file18} alt='xyz' />
                                        </div>
                                    </div>
                                </div>
                                <div className='row mt-3'>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange19} />
                                            <img src={file19} alt='xyz' />
                                        </div>
                                    </div>
                                    <div className='col-md-2'>
                                        <div className='upload-img-box'>
                                            <input type="file" id="myFile" name="filename" onChange={handleChange20} />
                                            <img src={file20} alt='xyz' />
                                        </div>
                                    </div>

                                </div>

                            </div>
                            <button type="submit" className="btn btn-outline-warning mt-1" >Submit</button>
                        </form>

                    </div>
                    
                    <div className='col-md-1'></div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default Formthree